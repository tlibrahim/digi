
  <div class="form-group">
      <label class="col-md-3 control-label" for="example-hf-password">Companies</label>
      <div class="col-md-7">
        <select class="form-control" id="contact1-subject" name="company_id" onchange="loadMyProjects(event)">
          <option></option>
          @foreach($companies as $c)
          <option value="{{ @$c['id'] }}">{{ @$c['name'] }}</option>
          @endforeach
        </select>
      </div>
  </div>
  <div class="form-group">
      <label class="col-md-3 control-label" for="example-hf-password">Customer Type</label>
      <div class="col-md-7">
        <select class="form-control" id="contact1-subject" name="customer_type" >
            <option value="Request a call">Request a call</option>
            <option value="Need Support">Need Support</option>
        </select>
      </div>
  </div>
  <div class="form-group">
      <label class="col-md-3 control-label" for="example-hf-password">Refarrer</label>
      <div class="col-md-7">
        <select class="form-control" name="project_id" id="reffer-projects">
        </select>
      </div>
  </div>
  <div class="form-group">
      <label class="col-md-3 control-label" for="example-hf-password">Source</label>
      <div class="col-md-7">
        <select class="form-control" id="contact1-subject" name="source" >
            <option value="1">Facebook Message</option>
            <option value="2">Facebook Comment</option>
            <option value="3">Facebook Leadgeneration</option>
            <option value="4">Website</option>
            <option value="5">Landing Page</option>
        </select>
      </div>
  </div>
  <div class="form-group">
      <label class="col-md-3 control-label" for="example-hf-email">Name</label>
      <div class="col-md-7">
          <input class="form-control" type="text" id="example-hf-email" name="name" placeholder="">
      </div>
  </div>
  <div class="form-group">
      <label class="col-md-3 control-label" for="example-hf-email">Phone</label>
      <div class="col-md-7">
          <input class="form-control" type="text" id="example-hf-email" name="phone" placeholder="">
      </div>
  </div>
  <div class="form-group">
      <label class="col-md-3 control-label" for="example-hf-email">Email</label>
      <div class="col-md-7">
          <input class="form-control" type="email" id="example-hf-email" name="email" placeholder="">
      </div>
  </div>
  <div class="form-group">
      <label class="col-md-3 control-label" for="example-hf-email">Customer Message</label>
      <div class="col-md-7">
          <input class="form-control" type="text" id="example-hf-email" name="message" placeholder="">
      </div>
  </div>
