@extends('layouts.app')

@section('content')
    
<!-- Main Container -->
<main id="main-container">

  <!-- Page Header -->
  <div class="content bg-gray-lighter">
      <div class="row items-push">
          <div class="col-sm-7">
              <h1 class="page-heading">
                  Customers <small>Requsted Call</small>
              </h1>
          </div>
          <div class="col-sm-5 text-right hidden-xs">
              <ol class="breadcrumb push-10-t">
                  <li>Requsted Call</li>
                  <li><a class="link-effect" href="">Customers</a></li>
              </ol>
          </div>
      </div>
  </div>
  <!-- END Page Header -->

    <!-- Stats -->
    <div class="content bg-white border">
        <div class="row items-push text-uppercase">
            <div class="col-xs-6 col-sm-2">
                <div class="font-w700  animated fadeIn">In Progress <span class="status progress"></span></div>
                <a class="h2 font-w300 text-primary animated flipInX" href="#">30</a>
            </div>
            <div class="col-xs-6 col-sm-2">
                <div class="font-w700 text-gray-darker animated fadeIn">Appointment</div>
                <a class="h2 font-w300 text-primary animated flipInX" href="#">5</a>
            </div>
            <div class="col-xs-6 col-sm-2">
                <div class="font-w700 text-gray-darker animated fadeIn">Call Back</div>
                <a class="h2 font-w300 text-primary animated flipInX" href="#">32</a>
            </div>
            <div class="col-xs-6 col-sm-2">
                <div class="font-w700 text-gray-darker animated fadeIn">Other Project</div>
                <a class="h2 font-w300 text-primary animated flipInX" href="#">32</a>
            </div>
            <div class="col-xs-6 col-sm-2">
                <div class="font-w700 text-gray-darker animated fadeIn">No Answer</div>
                <a class="h2 font-w300 text-primary animated flipInX" href="#">32</a>
            </div>
            <div class="col-xs-6 col-sm-2">
                <div class="font-w700 text-gray-darker animated fadeIn">Not Interested</div>
                <a class="h2 font-w300 text-primary animated flipInX" href="#">32</a>
            </div>
            <div class="col-xs-6 col-sm-2">
              <div class="form-group">
                  <div class="font-w700 text-gray-darker animated fadeIn">Date Range</div>
                    <br>
                    <div class="input-daterange input-group" data-date-format="mm/dd/yyyy">
                        <input class="form-control" type="text" id="example-daterange1" name="example-daterange1" placeholder="From">
                        <span class="input-group-addon"><i class="fa fa-chevron-right"></i></span>
                        <input class="form-control" type="text" id="example-daterange2" name="example-daterange2" placeholder="To">
                    </div>

              </div>
            </div>
            <div class="col-md-10">
              <div class="font-w700 text-gray-darker animated fadeIn">Filter</div>
              <br>
                <select class="js-select2 form-control" id="example-select2-multiple" name="example-select2-multiple" style="width: 100%;" data-placeholder="Choose many.." multiple>
                    <option></option><!-- Required for data-placeholder attribute to work with Chosen plugin -->
                    <option value="1">In Progress</option>
                    <option value="2">Appointment</option>
                    <option value="3">Call Back</option>
                    <option value="4">Other project</option>
                    <option value="5">No Answer</option>
                    <option value="6">Not Intrested</option>
                </select>


            </div>
        </div>
    </div>
    <!-- End Stats -->
    <div class="modal fade" id="customer" role="dialog">
      <div class="modal-dialog modal-dialog-popout">
        <div class="modal-content">
        	<form class="form-horizontal" action="{{ url('customers/add') }}" method="POST" onsubmit="addCustomer(event);return false;">
  				@csrf
	            <div class="block block-themed block-transparent remove-margin-b">
	                <div class="block-header bg-primary-dark">
	                    <ul class="block-options">
	                        <li>
	                            <button data-dismiss="modal" type="button" id="customer-close"><i class="si si-close"></i></button>
	                        </li>
	                    </ul>
	                    <h3 class="block-title">Add Customer</h3>
	                </div>
	                <div class="block-content">
	                	@include('customers.pop-up.add-lead')
	                </div>
	            </div>
	            <div class="modal-footer">
	                <button class="btn btn-sm btn-default" type="button" data-dismiss="modal">Close</button>
	                <button class="btn btn-sm btn-primary" type="submit"><i class="fa fa-check"></i> Ok</button>
	            </div>
	        </form>
        </div>
      </div>
    </div>
    <div class="modal fade" id="view" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-dialog-popout modal-lg">
        <div class="modal-content">
            <div class="block block-themed block-transparent remove-margin-b">
                <div class="block-header bg-primary-dark">
                    <ul class="block-options">
                        <li>
                            <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                        </li>
                    </ul>
                    <h3 class="block-title">View <small>Customer Name</small> History</h3>
                </div>
                <div class="block-content">
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-default" type="button" data-dismiss="modal">Close</button>
            </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="add" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-dialog-popout">
        <div class="modal-content">
            <div class="block block-themed block-transparent remove-margin-b">
                <div class="block-header bg-primary-dark">
                    <ul class="block-options">
                        <li>
                            <button data-dismiss="modal" type="button"><i class="si si-close"></i></button>
                        </li>
                    </ul>
                    <h3 class="block-title">View <small>Customer Name</small> History</h3>
                </div>
                <div class="block-content">
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-default" type="button" data-dismiss="modal">Close</button>
                <button class="btn btn-sm btn-primary" type="button" data-dismiss="modal"><i class="fa fa-check"></i> Ok</button>
            </div>
        </div>
      </div>
    </div>
      <div class="content">
        <!-- Simple Blocks -->
          <div class="row">
              <div class="col-sm-6 col-lg-12">
                  <div class="block block-bordered">
                      <div class="block-header bg-gray-lighter">
                          <ul class="block-options">
                              <li>
                                  <a class="btn btn-larg" data-toggle="modal" data-target="#customer" title="Add Connection"><i class="fa fa-plus"></i></a>
                              </li>
                          </ul>
                          <h3 class="block-title">Customers List</h3>
                      </div>
                      <div class="block-content">
                        <!-- Striped Table -->
                        <table class="table table-bordered table-striped js-dataTable-full">
                            <thead>
                                <tr>
                                    <th class="text-center" style="width: 50px;">ID</th>
                                    <th>Date/Time</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th class="hidden-xs">Customer Message</th>
                                    <th>Referrer</th>
                                    <th>source</th>
                                    <th class="">Feedback</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Today</td>
                                    <td>Hassan Shawa</td>
                                    <td>mhassan@digi-sail.com</td>
                                    <td>01001281110</td>
                                    <td>Need appartment with 106 space and garden</td>
                                    <td>Project Name</td>
                                    <td>Facebook Comment</td>
                                    <td>
                                        <div class="btn-group">
                                            <a ><button class="btn btn-xs btn-default" data-toggle="modal" data-target="#add" type="button" data-toggle="tooltip" title="Add Feedback"><i class="fa fa-plus"></i></button></a>
                                            <a ><button class="btn btn-xs btn-default" data-toggle="modal" data-target="#view" type="button" data-toggle="tooltip" title="View History"><i class="fa fa-eye"></i></button></a>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Yesterday</td>
                                    <td>Hassan Shawa</td>
                                    <td>mhassan@digi-sail.com</td>
                                    <td>01001281110</td>
                                    <td>Need appartment with 106 space and garden</td>
                                    <td>Project Name</td>
                                    <td>Facebook Comment</td>
                                    <td>
                                        <div class="btn-group">
                                            <a ><button class="btn btn-xs btn-default" data-toggle="modal" data-target="#add" type="button" data-toggle="tooltip" title="Add Feedback"><i class="fa fa-plus"></i></button></a>
                                            <a ><button class="btn btn-xs btn-default" data-toggle="modal" data-target="#view" type="button" data-toggle="tooltip" title="View History"><i class="fa fa-eye"></i></button></a>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <!-- END Striped Table -->
                      </div>
                  </div>
              </div>
          </div>
          <!-- END Simple Blocks -->
        </div>


    <!-- END Stats -->
  </main>
  <!-- END Main Container -->

@endsection

@section('scripts')
<script>
	function loadMyProjects(event){
		var url = '{{ url("load-projects") }}/'+$(event.target).val()
		$.ajax({
			type:'GET',
			dataType:'json',
			url:url,
			success:function(rData) {
				console.log(rData.code)
				$("#reffer-projects").html(rData.code)
			}
		})
	}

	function addCustomer(event) {
		$.ajax({
			type:'POST',
			dataType:'json',
			headers: {
  				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  			},
			url:'https://digi-sail.com/call/public/storecustomer',
			data:$(event.target).serialize(),
			success:function(rData) {
				swal({
					text:rData.status,
					icon:'success'
				})
				$("#customer-close").click()
				$("#customer-close").click()
			}
		})
	}
</script>
@endsection