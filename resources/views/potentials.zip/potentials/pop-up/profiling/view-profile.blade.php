<div id="view-profiling-modal" class="modal fade bd-example-modal-lg" role="dialog">
  	<div class="modal-dialog" style="width: 65%">
    	<div class="modal-content">
      		<div class="modal-header">
        		<button type="button" class="close" data-dismiss="modal">&times;</button>
        		<h4 class="modal-title">'{{ @$p->companyname }}' View Profile</h4>
      		</div>
      		<div class="clear-fix"></div>
      		<form id="view-profile-body">
			</form>
		</div>
	</div>
</div>