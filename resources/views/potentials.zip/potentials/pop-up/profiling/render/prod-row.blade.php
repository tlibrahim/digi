				<div style="position: relative;">
					<div class="form-group" style="width:100%">
	                  	<label class="col-md-3 control-label" style="font-size: ">Product / Services</label>
	                  	<div class="col-md-7">
	                    	<input class="form-control" style="width:100%" type="text" name="products[0][product]">
	                  	</div>
	                </div>
	                <i class="fa fa-times delete-in-profiling" title="Cancel Product/Service" onclick="cancelRow(event)"></i>
	            </div>