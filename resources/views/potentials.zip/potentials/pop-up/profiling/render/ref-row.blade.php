				<div style="position: relative;">
					<h3 class="block-title s-line"></h3>
	                <div class="form-group" style="width:100%">
	                  	<label class="col-md-3 control-label">Refrance</label>
	                  	<div class="col-md-7">
	                    	<input class="form-control" style="width:100%" type="text" name="refs[0][reference]">
	                  	</div>
	                </div>
	                <div class="form-group" style="width:100%">
	                  	<label class="col-md-3 control-label">Broviding Services</label>
	                  	<div class="col-md-7">
	                    	<textarea class="form-control" style="width:100%" name="refs[0][providing]" rows="5"></textarea>
	                  	</div>
	                </div>
	                <i class="fa fa-times delete-in-profiling" title="Cancel Reference" onclick="cancelRow(event)"></i>
	            </div>