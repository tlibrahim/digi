<div id="add-connection-{{ @$p->id }}" class="modal fade" role="dialog">
  	<div class="modal-dialog">
    	<div class="modal-content">
      		<div class="modal-header">
        		<button type="button" class="close" data-dismiss="modal">&times;</button>
        		<h4 class="modal-title">'{{ @$p->companyname }}' Add Connection</h4>
      		</div>
      		<form method="post" action="{{ url('potentials/connection/'.@$p->id.'/add') }}">
	      		<div class="modal-body">
					@csrf
					<input type="hidden" name="potential_id" value="{{ @$p->id }}">
					<div class="form-group" style="width:100%">
						<label>First Name</label>
						<input style="width:100%" type="text" required placeholder="First Name" name="firstname" class="form-control">
					</div>
					<div class="form-group" style="width:100%">
						<label>Last Name</label>
						<input style="width:100%" type="text" required placeholder="Last Name" name="lastname" class="form-control">
					</div>
					<div class="form-group" style="width:100%">
						<label>Position</label>
						<input style="width:100%" type="text" required placeholder="Position" name="position" class="form-control">
					</div>
					<div class="form-group" style="width:100%">
						<label>Phone</label>
						<input style="width:100%" type="text" required placeholder="Phone" name="phone" class="form-control">
					</div>
					<div class="form-group" style="width:100%">
						<label>Email</label>
						<input style="width:100%" type="email" required placeholder="Email" name="email" class="form-control">
					</div>
					<div class="form-group" style="width:100%">
						<label>Address</label>
						<input style="width:100%" type="text" placeholder="Address" name="address" class="form-control">
					</div>
					<div class="modal-footer" style="padding: 15px 0">
						<button class="btn btn-primary pull-right">Save</button>
			        	<button type="button" class="btn btn-default pull-left" data-dismiss="modal" style="margin-left: 0">Close</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>